package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.tarea;
import model.contactos;
/**
 * Servlet implementation class AltaContactos
 */
@WebServlet("/AltaContactos")
public class AltaContactos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AltaContactos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String name = request.getParameter("name");
		int edad = Integer.parseInt(request.getParameter("edad"));
		String sexo = request.getParameter("sexo");
		double altura = Integer.parseInt(request.getParameter("altura"));
		String nacionalidad = request.getParameter("nacionalidad");
		String correo = request.getParameter("correo");
		
		contactos c = new contactos(sexo, edad, sexo, altura, nacionalidad, correo);
        c.setName(name);
        c.setEdad(edad);
        c.setSexo(sexo);
        c.setAltura(altura);
        c.setNacionalidad(nacionalidad);
        c.setCorreo(correo);
        
        
    	try {
			Class.forName("com.mysql.jdbc.Driver");// Cargar el driver
				// Establecemos la conexion con la BD
				Connection conexion = DriverManager.getConnection
						("jdbc:mysql://localhost/GestorTareas", "root", "root");
											
				
				
				// construir orden INSERT
				String sql = "INSERT INTO tareas (titulo,descripcion,categoria,importacia,dependencia, f_inicio,f_final, estado) "
						+ "VALUES "
						+ "( ?, ?, ?, ?, ?, ?, ?, ? )";
  			   			    
				
				PreparedStatement sentencia = 
						conexion.prepareStatement(sql);
				
				
				sentencia.setString(1, c.getName());
				sentencia.setInt(2, c.getEdad());
				sentencia.setString(3, c.getSexo());
				sentencia.setDouble(4, c.getAltura());
				sentencia.setString(5, c.getNacionalidad());
				
							
				int filas;
				try {
				 filas = sentencia.executeUpdate();
				  System.out.println("Filas afectadas: " + filas);
				} catch (SQLException e) {
					System.out.println("HA OCURRIDO UNA EXCEPCIâ€N:"); 
				    System.out.println("Mensaje:    "+ e.getMessage()); 
				    System.out.println("SQL estado: "+ e.getSQLState()); 
			    	System.out.println("CÃ›d error:  "+ e.getErrorCode());  
				}
				
				

				sentencia.close(); // Cerrar Statement
				conexion.close(); // Cerrar conexiÃ›n

			} catch (ClassNotFoundException cn) {
				cn.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}


		
		
		
		

		
		
	
		
		
		
		
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
