package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.tarea;

/**
 * Servlet implementation class AltaTarea
 */
@WebServlet("/AltaTarea")
public class AltaTarea extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AltaTarea() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String titulo = request.getParameter("titulo");
		String descripcion = request.getParameter("descripcion");
		int categoria = Integer.parseInt(request.getParameter("categoria"));
		int importancia = Integer.parseInt(request.getParameter("importancia"));
		int dependencia = Integer.parseInt(request.getParameter("dependencia"));
		int estado = Integer.parseInt(request.getParameter("estado"));
		/*
		SimpleDateFormat fecha_ini=new SimpleDateFormat("dd/MM/yyyy");
		String fecha=request.getParameter("f_inicio");
		fecha=fecha_ini.format(new Date());
		
		SimpleDateFormat fecha_fin=new SimpleDateFormat("dd/MM/yyyy");
		String fecha_fi=request.getParameter("f_final");
		fecha_fi=fecha_fin.format(new Date());
		
		*/

		Date f_inicio = new Date();
		Date f_final = new Date();
		try {
			 f_inicio = new SimpleDateFormat().parse(request.getParameter("f_inicio"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			 f_final = new SimpleDateFormat().parse(request.getParameter("f_final"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Crear objeto
		
		tarea t = new tarea();
		t.setTitulo(titulo);
		t.setDescripcion(descripcion);
		t.setCategoria(categoria);
		t.setImportancia(importancia);
		t.setDependencia(dependencia);
		t.setF_inicio(f_inicio);		
		t.setF_final(f_final);
		t.setEstado(estado);
		
		t.insertar();
		
		//response.getWriter().print("<p>"+t.toString()+"</p>");
		//System.out.println(t.toString());

		try {
			Class.forName("com.mysql.jdbc.Driver");// Cargar el driver
				// Establecemos la conexion con la BD
				Connection conexion = DriverManager.getConnection
						("jdbc:mysql://localhost/GestorTareas", "root", "root");
											
				
				
				// construir orden INSERT
				String sql = "INSERT INTO tareas (titulo,descripcion,categoria,importacia,dependencia, f_inicio,f_final, estado) "
						+ "VALUES "
						+ "( ?, ?, ?, ?, ?, ?, ?, ? )";
  			   			    
				
				PreparedStatement sentencia = 
						conexion.prepareStatement(sql);
				
				
				sentencia.setString(1, t.getTitulo());
				sentencia.setString(2, t.getDescripcion());
				sentencia.setInt(3, t.getCategoria());
				sentencia.setInt(4, t.getImportancia());
				sentencia.setInt(5, t.getDependencia());
				
				sentencia.setString(6, t.dameF_inicioSQL());
				sentencia.setString(7, t.dameF_finalSQL());
				
				sentencia.setInt(8, t.getEstado());

				
				int filas;
				try {
				 filas = sentencia.executeUpdate();
				  System.out.println("Filas afectadas: " + filas);
				} catch (SQLException e) {
					System.out.println("HA OCURRIDO UNA EXCEPCIâ€N:"); 
				    System.out.println("Mensaje:    "+ e.getMessage()); 
				    System.out.println("SQL estado: "+ e.getSQLState()); 
			    	System.out.println("CÃ›d error:  "+ e.getErrorCode());  
				}
				
				

				sentencia.close(); // Cerrar Statement
				conexion.close(); // Cerrar conexiÃ›n

			} catch (ClassNotFoundException cn) {
				cn.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		
				
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
