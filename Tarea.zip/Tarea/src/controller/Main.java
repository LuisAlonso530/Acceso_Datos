package controller;
import java.sql.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			Class.forName("com.mysql.jdbc.Driver");// Cargar el driver
				// Establecemos la conexion con la BD
				Connection conexion = DriverManager.getConnection
						("jdbc:mysql://vl21970.dinaserver.com", "uss024", "halcon2019");
											
				
				// construir orden INSERT
				String sql = "INSERT INTO departamentos VALUES "
						+ "( ?, ?, ?, ? )";
  			    
				System.out.println(sql);  			    
				PreparedStatement sentencia = 
						conexion.prepareStatement(sql);				
				sentencia.setInt(1, Integer.parseInt("2"));
				sentencia.setString(2, "nombre");
				sentencia.setString(3, "apellido");
				sentencia.setString(4, "email");
				
				int filas;//
				try {
				  filas = sentencia.executeUpdate();
				  System.out.println("Filas afectadas: " + filas);
				} catch (SQLException e) {
					System.out.println("HA OCURRIDO UNA EXCEPCIâ€N:"); 
				    System.out.println("Mensaje:    "+ e.getMessage()); 
				    System.out.println("SQL estado: "+ e.getSQLState()); 
			    	System.out.println("CÃ›d error:  "+ e.getErrorCode());  
				}
				
				

				sentencia.close(); // Cerrar Statement
				conexion.close(); // Cerrar conexiÃ›n

			} catch (ClassNotFoundException cn) {
				cn.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}

}
