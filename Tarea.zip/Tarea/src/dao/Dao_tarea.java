package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import connection.DBConnection;
import model.tarea;

public class Dao_tarea {

	private Connection con = null;

	public static Dao_tarea instance = null;

	public Dao_tarea() throws SQLException {
		con = DBConnection.getConnection();
	}

	public static Dao_tarea getInstance() throws SQLException {
		if (instance == null)
			instance = new Dao_tarea();
		return instance;
	}
	public void insert(tarea t) throws SQLException {
		PreparedStatement ps = con.prepareStatement("INSERT INTO tarea"
				+ " (titulo, descricpcion ...., ) VALUES (?,?,?,?,?,?,?,?,?)");
		ps.setString(1, t.getTitulo());
		ps.setString(2, t.getDescripcion());
		ps.setInt(3, t.getCategoria());
		ps.setInt(4, t.getImportancia());
		ps.setDate(5, t.getF_inicio());
		ps.setDate(6, t.getF_final());
		ps.setInt(7, t.getDependencia());
		ps.setInt(8, t.getEstado());
		
		ps.executeUpdate();
		ps.close();
		
		 
	}
	
	public void update(tarea t) throws SQLException {
		PreparedStatement ps = con.prepareStatement("UPDATE tarea SET titulo = ?, descripcion = ? ... WHERE id = ? ");
		ps.setString(1, t.getTitulo());
		
		ps.executeUpdate();
		ps.close();

	}
		public ArrayList<tarea> listaTareas(){
			
			ArrayList<tarea> lista = null;
					
				try {
					PreparedStatement ps = con.prepareStatement("SELECT * FROM tarea");
				
				 ResultSet resultado;
				
					resultado = ps.executeQuery();
				
				 
					
						while(resultado.next()) {
							
							
							tarea t = new tarea(resultado.getInt("id"), resultado.getString("titulo"), 
									resultado.getString("descripcion"), resultado.getInt("categoria"),
									resultado.getInt("importancia"), resultado.getDate("f_inicio"), resultado.getDate("f_final"),
									resultado.getInt("dependencia"),resultado.getInt("estado"));
							
							lista.add(t);
	}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				return lista;
		}
		
		
	}

		
		
		
		
	
	


