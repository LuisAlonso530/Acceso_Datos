package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	private static final String JDBC_URL="jdbc:mysql://halifaxtraining.es:3306/ciberkaosprof";
	private static Connection instance=null;
	
	private DBConnection() {
	}

	public static Connection getConnection() throws SQLException {

		if (instance == null) {
			Properties props = new Properties();
			props.put("user", "uss024");
			props.put("password", "halcon2019");
			instance = DriverManager.getConnection(JDBC_URL, props);
		}
		return instance;
	}
	

	

	

}
