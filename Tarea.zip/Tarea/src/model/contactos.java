package model;

public class contactos {

	private String name;
	private int edad;
	private String sexo;
	private double altura;
	private String nacionalidad;
	private String correo;
	
	public contactos(String name, int edad, String sexo, double altura, String nacionalidad, String correo) {
		super();
		
		this.name=name;
		this.edad=edad;
		this.sexo=sexo;
		this.altura=altura;
		this.nacionalidad=nacionalidad;
		this.correo=correo;
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public String getNacionalidad() {
		return nacionalidad;
	}

	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	@Override
	public String toString() {
		return "contactos [name=" + name + ", edad=" + edad + ", sexo=" + sexo + ", altura=" + altura
				+ ", nacionalidad=" + nacionalidad + ", correo=" + correo + "]";
	}
	
	
	
}
