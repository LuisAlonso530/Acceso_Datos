package model;

import java.sql.SQLException;
import java.util.ArrayList;

import dao.Dao_tarea;

public class ListaTareas {
	
	ArrayList<tarea> lista;
	
	public ArrayList<tarea> obtenerTareas(){
		
		
	try {
		lista = Dao_tarea.getInstance().listaTareas();
		
	}catch (SQLException e) {
		e.printStackTrace();
	}
           return lista;
}
}
